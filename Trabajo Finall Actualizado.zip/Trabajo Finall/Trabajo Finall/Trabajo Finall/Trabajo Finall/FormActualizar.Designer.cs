﻿using System;

namespace Trabajo_Finall
{
    partial class FormActualizar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.VistaLista = new System.Windows.Forms.DataGridView();
            this.Agregar = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.TraterLista = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.textBoxDescripcion = new System.Windows.Forms.TextBox();
            this.textBoxTitle = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.VistaLista)).BeginInit();
            this.SuspendLayout();
            // 
            // VistaLista
            // 
            this.VistaLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.VistaLista.Location = new System.Drawing.Point(157, 209);
            this.VistaLista.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.VistaLista.Name = "VistaLista";
            this.VistaLista.RowHeadersWidth = 51;
            this.VistaLista.RowTemplate.Height = 24;
            this.VistaLista.Size = new System.Drawing.Size(509, 229);
            this.VistaLista.TabIndex = 0;
            this.VistaLista.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.VistaLista_CellContentClick);
            // 
            // Agregar
            // 
            this.Agregar.Location = new System.Drawing.Point(287, 167);
            this.Agregar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Agregar.Name = "Agregar";
            this.Agregar.Size = new System.Drawing.Size(75, 38);
            this.Agregar.TabIndex = 1;
            this.Agregar.Text = "Agregar";
            this.Agregar.UseVisualStyleBackColor = true;
            this.Agregar.AutoSizeChanged += new System.EventHandler(this.AgregarNuevo);
            this.Agregar.Click += new System.EventHandler(this.Agregar_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(368, 167);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 38);
            this.button3.TabIndex = 3;
            this.button3.Text = "Limpiar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.AutoSizeChanged += new System.EventHandler(this.AgregarNuevo);
            this.button3.Click += new System.EventHandler(this.Limpiar);
            // 
            // TraterLista
            // 
            this.TraterLista.Location = new System.Drawing.Point(547, 167);
            this.TraterLista.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TraterLista.Name = "TraterLista";
            this.TraterLista.Size = new System.Drawing.Size(84, 38);
            this.TraterLista.TabIndex = 4;
            this.TraterLista.Text = "TraerLista";
            this.TraterLista.UseVisualStyleBackColor = true;
            this.TraterLista.AutoSizeChanged += new System.EventHandler(this.AgregarNuevo);
            this.TraterLista.Click += new System.EventHandler(this.TraterLista_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(317, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(304, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Title";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(299, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(253, 121);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Descriprcion";
            // 
            // textBoxId
            // 
            this.textBoxId.Location = new System.Drawing.Point(343, 49);
            this.textBoxId.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(100, 22);
            this.textBoxId.TabIndex = 9;
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(343, 96);
            this.textBoxPrice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(100, 22);
            this.textBoxPrice.TabIndex = 10;
            // 
            // textBoxDescripcion
            // 
            this.textBoxDescripcion.Location = new System.Drawing.Point(343, 121);
            this.textBoxDescripcion.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxDescripcion.Name = "textBoxDescripcion";
            this.textBoxDescripcion.Size = new System.Drawing.Size(100, 22);
            this.textBoxDescripcion.TabIndex = 11;
            // 
            // textBoxTitle
            // 
            this.textBoxTitle.Location = new System.Drawing.Point(343, 74);
            this.textBoxTitle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxTitle.Name = "textBoxTitle";
            this.textBoxTitle.Size = new System.Drawing.Size(100, 22);
            this.textBoxTitle.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(455, 167);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 38);
            this.button1.TabIndex = 13;
            this.button1.Text = "Modificar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Modificar);
            // 
            // FormActualizar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxTitle);
            this.Controls.Add(this.textBoxDescripcion);
            this.Controls.Add(this.textBoxPrice);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TraterLista);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.Agregar);
            this.Controls.Add(this.VistaLista);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormActualizar";
            this.Text = "FormActualizar";
            ((System.ComponentModel.ISupportInitialize)(this.VistaLista)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

     


        #endregion

        private System.Windows.Forms.DataGridView VistaLista;
        private System.Windows.Forms.Button Agregar;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button TraterLista;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.TextBox textBoxDescripcion;
        private System.Windows.Forms.TextBox textBoxTitle;
        private System.Windows.Forms.Button button1;
    }
}