﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Trabajo_Finall.Modelos;

namespace Trabajo_Finall
{
    public partial class FormActualizar : Form
    {
        int Poc;

        ConexionApi conexionApi = new ConexionApi();
        public FormActualizar()
        {
            InitializeComponent();
        }

        private void AgregarNuevo(object sender, EventArgs e)
        {
            int n=VistaLista.Rows.Add();
            VistaLista.Rows[n].Cells[0].Value = textBoxId.Text;
            VistaLista.Rows[n].Cells[1].Value = textBoxTitle.Text;
            VistaLista.Rows[n].Cells[2].Value = textBoxPrice.Text;
            VistaLista.Rows[n].Cells[3].Value = textBoxDescripcion.Text;

        }

        private void Limpiar(object sender, EventArgs e)
        {
            textBoxTitle.Text = "";
            textBoxPrice.Text = "";
            textBoxDescripcion.Text= "";
        }

        private void EliminarProd(object sender, EventArgs e)
        {
            
            MessageBox.Show("Se elimino el prodcuto");

        }

        private void TraterLista_Click(object sender, EventArgs e)
        {
            
            VistaLista.DataSource = conexionApi.GetProductos();

        }

        private void Modificar(object sender, EventArgs e)
        {
            VistaLista[1, Poc].Value = textBoxTitle.Text;
            VistaLista[2, Poc].Value= textBoxPrice.Text;
            VistaLista[3, Poc].Value=textBoxDescripcion.Text;
        }

        private void VistaLista_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Poc = VistaLista.CurrentRow.Index;
            textBoxTitle.Text = VistaLista[1,Poc].ToString();
            textBoxTitle.Text = VistaLista[2,Poc].ToString();
            textBoxTitle.Text = VistaLista[3,Poc].ToString();
        }

        private void Agregar_Click(object sender, EventArgs e)
        {
            try
            {
                Producto Nproducto = new Producto();
                Nproducto.Title = textBoxTitle.Text;
                Nproducto.Id = Convert.ToInt32(textBoxId.Text);
                Nproducto.Price = Convert.ToDecimal(textBoxPrice.Text);
                Nproducto.Description = textBoxDescripcion.Text;

                VistaLista.DataSource = conexionApi.AddProducto(Nproducto);
            }
            catch
            {
                MessageBox.Show("Ingrese el campo solicitado o los campos restantes");

            }





        }

    }
}
