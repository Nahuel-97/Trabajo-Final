﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using Trabajo_Finall.Modelos;

namespace Trabajo_Finall
{
    public partial class FormPrincipal : Form
    {
        ConexionApi conexionApi = new ConexionApi();
        int Poc;
        public FormPrincipal()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        
        private void Categoria_Click(object sender, EventArgs e)
        {

            
        }

        private void Descendente_Click(object sender, EventArgs e)
        {

            dataGridView1.DataSource=conexionApi.Descendente();
        }

        private void Ascendente(object sender, EventArgs e)
        {
            
        }


        private void ActualizarProductos(object sender, EventArgs e)
        {
            FormActualizar formActualizar = new FormActualizar();
            formActualizar.ShowDialog();
        }


        private void MostrarLista_Click(object sender, EventArgs e)
        {
            categoria.Items.Add("jewelery");
            categoria.Items.Add("jewelery");
            categoria.Items.Add("jewelery");
            categoria.Items.Add("jewelery");
            dataGridView1.DataSource = conexionApi.GetProductos();
            
        }

        private void FiltrarCategoria(object sender, EventArgs e)
        {
            dataGridView1.DataSource = conexionApi.Categoria();
        }

        private void Eliminar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Se elimino el prodcuto");
        }

       

        private void Modificar_Click(object sender, EventArgs e)
        {
          
        }
    }
    }


