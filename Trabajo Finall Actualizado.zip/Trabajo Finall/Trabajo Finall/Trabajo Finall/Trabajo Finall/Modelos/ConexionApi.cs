﻿using RestSharp.Authenticators;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trabajo_Finall.Properties;
using System.Runtime.Remoting.Messaging;
using Trabajo_Finall.Modelos;
using System.Windows.Forms;
using System.Diagnostics.Eventing.Reader;

namespace Trabajo_Finall
{
    internal class ConexionApi
    {

     
        RestClient client = new RestClient("https://fakestoreapi.com/products");



        public List<Producto> GetProductos()
        {
            var request = new RestRequest("", Method.Get);
            List<Producto> productos = client.Get<List<Producto>>(request);
            return productos;
        }

        public List<Producto> AddProducto(Producto producto)
        {
            var request = new RestRequest("", Method.Get);
            List<Producto> product = client.Get<List<Producto>>(request);
            product.Add(producto);
            return product;
        }

    public List<Producto> Descendente()
    {
        var client = new RestClient();
        var request = new RestRequest("https://fakestoreapi.com/products?sort=desc", Method.Get);
        List<Producto> productos = client.Get<List<Producto>>(request);
        return productos;



    }

        public List<Producto> Ascendente()
        {
            var client = new RestClient();
            var request = new RestRequest("", Method.Get);
            List<Producto> productos = client.Get<List<Producto>>(request);
            return productos;



        }

        public List<Producto> Categoria()
        {
            
            
            var client = new RestClient();
            var request = new RestRequest("https://fakestoreapi.com/products/category/jewelery", Method.Get);
            List<Producto> productos = client.Get<List<Producto>>(request);
            return productos;

          
        }
    }
}










